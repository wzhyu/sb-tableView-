//
//  myVC.m
//  sb实现的表
//
//  Created by 杭州共联房地产 on 17/3/16.
//  Copyright © 2017年 杭州共联房地产. All rights reserved.
//

#import "myVC.h"


@interface myVC ()<UITextViewDelegate>

@property (weak, nonatomic) IBOutlet UITextView *textview;

@end

@implementation myVC




static NSInteger count = 0;



- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    /*
           [_textview setTextColor:[UIColor blackColor]];
           _textview.backgroundColor = [UIColor redColor];
            [_textview.layer setBorderColor:[[UIColor blackColor] CGColor]];
            [_textview setFont:[UIFont systemFontOfSize:15]];
            [_textview.layer setBorderWidth:1.0f];
           [_textview setDelegate:self];
    
   */
    self.navigationItem.leftBarButtonItem = self.editButtonItem;
    self.navigationItem.title = @"我是普通视图";
    
    NSLog(@"%@",self.tabBarItem.title);
   // self.tabBarItem.badgeValue = @"25";
   // self.tabBarItem.badgeColor = [UIColor orangeColor];
       self.navigationController.tabBarItem.title = @"kkk";
    NSLog(@"%@",self.tabBarItem.badgeValue);
    
  //  [NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(lai) userInfo:nil repeats:YES];
    
   
    
}

-(void)lai{

    count++;
    
    self.navigationController.tabBarItem.badgeValue = [NSString stringWithFormat:@"%d",count];//
    
    [[NSNotificationCenter defaultCenter] postNotificationName:@"chang" object:nil userInfo:@{@"badge":@(count)}];

}

-(void)textViewDidChange:(UITextView *)textView{
    static CGFloat maxHeight =60.0f;
    CGRect frame = textView.frame;
    CGSize constraintSize = CGSizeMake(frame.size.width, MAXFLOAT);
    CGSize size = [textView sizeThatFits:constraintSize];
    
    NSLog(@"%@",NSStringFromCGSize(size));
    if (size.height<=frame.size.height) {
        size.height=frame.size.height;
    }else{
        if (size.height >= maxHeight)
        {
            size.height = maxHeight;
            textView.scrollEnabled = YES;   // 允许滚动
        }
        else
        {
            textView.scrollEnabled = NO;    // 不允许滚动
        }
    }
    textView.frame = CGRectMake(frame.origin.x, frame.origin.y, frame.size.width, size.height);
}
@end
