//
//  MyCell.h
//  sb实现的表
//
//  Created by 杭州共联房地产 on 17/3/16.
//  Copyright © 2017年 杭州共联房地产. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "people.h"


@interface MyCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UIImageView *img;

@property (weak, nonatomic) IBOutlet UILabel *name;

@property (weak, nonatomic) IBOutlet UILabel *comment;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *lblHeight;
@property (weak, nonatomic) IBOutlet UIButton *edit;

@property(nonatomic,strong)people *p;
- (CGFloat)cellHeightWithStatus:(people *)p;
@end
