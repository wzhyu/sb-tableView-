//
//  TableViewVC.m
//  sb实现的表
//
//  Created by 杭州共联房地产 on 17/3/16.
//  Copyright © 2017年 杭州共联房地产. All rights reserved.
//

#import "TableViewVC.h"
#import "people.h"
#import "MyCell.h"


@interface TableViewVC ()
@property(nonatomic,strong)NSMutableArray *array;

@end

@implementation TableViewVC

-(NSMutableArray *)array{
    if (!_array){
        _array=[[NSMutableArray alloc]init];
        
    }
    return _array;
}



- (void)viewDidLoad {
    [super viewDidLoad];
    
    // Uncomment the following line to preserve selection between presentations.
    // self.clearsSelectionOnViewWillAppear = NO;
    
    // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
    self.navigationItem.rightBarButtonItem = self.editButtonItem;
    self.navigationItem.title = @"我是表视图";
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(lai:) name:@"chang" object:nil];
    
    
    for (int i=0; i<10; i++) {
        people *p = [[people alloc]init];
        p.img = @"1";
        p.name = @"你爹";
        p.comment =@"iOS8在调用系统相机拍照时，会有一两秒的停顿，然后再弹出UIImagePickConroller，IOS7是没有这个问题的,解决问题的关键部分来了，IOS8多了一个样式UIModalPresentationOverCurrentContext，IOS8中presentViewController时请将控制器的modalPresentationStyle设置为UIModalPresentationOverCurrentContext，问题解决";
        
        if (i%3==0) {
             p.comment =@"iOS8在调用系统相机拍照时，会有一两秒的停顿，然后再弹出UIImagePickConroller，IOS7是没有这个问题的,解器的modalPresentationStyle设置为UIModalPresentationOverCurrentContext，问题解决";
        }
        
        
        [self.array addObject:p];
    }
    
    
    self.tableView.rowHeight = UITableViewAutomaticDimension;//设置行高为自动计算
    self.tableView.estimatedRowHeight = 100;//预计行高
   // [self.tableView registerClass:[MyCell class] forCellReuseIdentifier:@"abc"];
    [self.tableView reloadData];
}

-(void)lai:(NSNotification *)userInfo{
    
    self.navigationController.tabBarItem.badgeValue  =  [userInfo.userInfo[@"badge"] description];
 
    NSLog(@"%@",userInfo.userInfo[@"badge"]);
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.array.count;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
  
    
    static NSString * cellId = @"abc";
    MyCell * cell = [tableView dequeueReusableCellWithIdentifier:cellId];
    if (!cell) {
        cell = [tableView dequeueReusableCellWithIdentifier:cellId forIndexPath:indexPath];
    }
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    people *p = self.array[indexPath.row];
    cell.p=p;
    return cell;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
   
   MyCell *cell = [tableView dequeueReusableCellWithIdentifier:@"abc"];
  
    people *p = self.array[indexPath.row];
    NSLog(@"%f------",[cell cellHeightWithStatus:p]);
    
    return [cell cellHeightWithStatus:p]+20;
}

@end
