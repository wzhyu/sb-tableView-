//
//  MyCell.m
//  sb实现的表
//
//  Created by 杭州共联房地产 on 17/3/16.
//  Copyright © 2017年 杭州共联房地产. All rights reserved.
//

#import "MyCell.h"

@implementation MyCell

- (void)awakeFromNib {
    [super awakeFromNib];
  }

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

-(void)setP:(people *)p{
    
    if (_p !=p) {
        _p=p;
    };
    
    //NSLog(@"%@",p.name);
    _img.backgroundColor = [UIColor redColor];
    _name.text = p.name;
    _comment.text = p.comment;
   // NSLog(@"%@",_img);
   
   }

- (CGFloat)cellHeightWithStatus:(people *)p
{
    self.p = p;//这个地方等于把上面那个重新调用了
    // 调用layoutIfNeeded方法, 会从当前控件开始更新所有的子控件和自己
    [self layoutIfNeeded];
    
    CGFloat  imgHeight = self.img.frame.size.height;
    CGFloat  lbHeight =CGRectGetMaxY(self.comment.frame);
    
    NSLog(@"%f---%f---%f",self.comment.frame.size.height,imgHeight,lbHeight);

    return imgHeight>=lbHeight?imgHeight:lbHeight;
}

@end
