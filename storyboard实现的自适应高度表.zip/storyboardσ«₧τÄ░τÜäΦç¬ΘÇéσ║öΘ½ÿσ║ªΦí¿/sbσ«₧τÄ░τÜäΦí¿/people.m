//
//  people.m
//  sb实现的表
//
//  Created by 杭州共联房地产 on 17/3/16.
//  Copyright © 2017年 杭州共联房地产. All rights reserved.
//

#import "people.h"

@implementation people

@end
