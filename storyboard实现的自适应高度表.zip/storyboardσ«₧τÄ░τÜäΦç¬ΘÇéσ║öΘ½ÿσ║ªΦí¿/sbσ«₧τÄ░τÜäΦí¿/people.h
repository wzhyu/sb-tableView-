//
//  people.h
//  sb实现的表
//
//  Created by 杭州共联房地产 on 17/3/16.
//  Copyright © 2017年 杭州共联房地产. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface people : NSObject

@property(nonatomic,copy)NSString  *img;
@property(nonatomic,copy)NSString *name;
@property(nonatomic,copy)NSString *comment;
@end
